﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Design_Car_Class
{
    public class Car
    {
        public int YearModel { get; set; }
        public string Make { get; set; }
        public double Speed { get; set; }

        public Car(int yearmodel, string make)
        {
            this.YearModel = yearmodel;
            this.Make = make;
            this.Speed = Speed;
        }

        public Car()
        {
            Console.WriteLine("Please enter Year Model of the car");
            YearModel = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please enter the Make of the car");
            Make = Console.ReadLine();
        }

        public void Accelerate()
        {
            Speed += 5;
        }

        public void Brake()
        {
            if(Speed <= 0)
            {
                Console.WriteLine("Your car is already at the lowest speed");
            }
            else
            {
                Speed = Speed - 5;
            }
        }
    }
}
